import '../models/ebook.dart';

const EbookData = const [
  Ebook(
    id: 'b1',
    bookcover: 'assets/images/ebook/tptgfirst.png',
    bookPdf: 'https://online.pubhtml5.com/xvgw/ojdg',
  ),
];
