class Ebook {
  final String id;
  final String bookcover;
  final String bookPdf;

  const Ebook({
    required this.id,
    required this.bookcover,
    required this.bookPdf,
  });
}
